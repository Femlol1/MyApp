package com.example.victa_authenticator;

public class User {

    public String fullname, ID, email;

    public User() {

    }

    public User(String fullname, String ID, String email) {
        this.fullname = fullname;
        this.ID = ID;
        this.email = email;
    }
}
